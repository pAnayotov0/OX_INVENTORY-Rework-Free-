return {
	{
		coords = vec3(464.53, -1000.5, 31.1),
		target = {
			loc = vec3(464.53, -1000.5, 31.1),
			length = 1.2,
			width = 5.6,
			heading = 0,
			minZ = 29.49,
			maxZ = 32.09,
			label = 'Open personal locker'
		},
		name = 'policelocker',
		label = 'Лично шкафче',
		owner = true,
		slots = 40,
		weight = 70000,
		groups = shared.police
	},

	{
		coords = vec3(301.3, -600.23, 43.28),
		target = {
			loc = vec3(301.82, -600.99, 43.29),
			length = 0.6,
			width = 1.8,
			heading = 340,
			minZ = 43.34,
			maxZ = 44.74,
			label = 'Open personal locker'
		},
		name = 'emslocker',
		label = 'Лично шкафче',
		owner = true,
		slots = 40,
		weight = 70000,
		groups = {['ambulance'] = 0}
	},
}
