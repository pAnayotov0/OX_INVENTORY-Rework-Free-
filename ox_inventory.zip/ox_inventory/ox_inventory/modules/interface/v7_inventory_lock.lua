-- V7 inventory movement lock
-- Blocks movement while the NUI inventory has focus.

local wasFrozen = false

CreateThread(function()
    while true do
        if IsNuiFocused() then
            local ped = PlayerPedId()

            DisableControlAction(0, 30, true)
            DisableControlAction(0, 31, true)
            DisableControlAction(0, 32, true)
            DisableControlAction(0, 33, true)
            DisableControlAction(0, 34, true)
            DisableControlAction(0, 35, true)
            DisableControlAction(0, 21, true)
            DisableControlAction(0, 22, true)
            DisableControlAction(0, 24, true)
            DisableControlAction(0, 25, true)
            DisableControlAction(0, 37, true)
            DisableControlAction(0, 44, true)
            DisableControlAction(0, 140, true)
            DisableControlAction(0, 141, true)
            DisableControlAction(0, 142, true)
            DisableControlAction(0, 257, true)
            DisableControlAction(0, 263, true)
            DisableControlAction(0, 264, true)

            DisableControlAction(0, 59, true)
            DisableControlAction(0, 60, true)
            DisableControlAction(0, 63, true)
            DisableControlAction(0, 64, true)
            DisableControlAction(0, 71, true)
            DisableControlAction(0, 72, true)
            DisableControlAction(0, 75, true)

            if ped and ped ~= 0 then
                FreezeEntityPosition(ped, true)
                wasFrozen = true
            end

            Wait(0)
        else
            if wasFrozen then
                local ped = PlayerPedId()
                if ped and ped ~= 0 then
                    FreezeEntityPosition(ped, false)
                end
                wasFrozen = false
            end

            Wait(150)
        end
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        local ped = PlayerPedId()
        if ped and ped ~= 0 then
            FreezeEntityPosition(ped, false)
        end
    end
end)
